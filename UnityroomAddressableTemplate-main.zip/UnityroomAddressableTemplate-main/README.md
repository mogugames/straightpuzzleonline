# UnityroomAddressableTemplate
Template project for using Addressable in unityroom

# How to Use (ja)
https://zenn.dev/uimss/articles/9912f9d7147853
